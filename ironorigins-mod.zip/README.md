# Iron Origins (addon do Iron's Spells 'n Spellbooks) — Forge 1.20.1

## O que tem
- **Raças** (Humano, Elfo, Anão, Orc, Tiefling): bônus/penalidades de mana, poder mágico, vida, armadura, dano.
- **Classes** (Mago, Guerreiro, Clérigo, Ladino, **Arqueiro**, Druida, **Cozinheiro**, **Artesão de Golens**): roupas básicas de couro tingido, stats, itens exclusivos e **árvore de habilidades própria**. Classes de feitiço começam com um pergaminho; Arqueiro, Cozinheiro e Artesão não usam magia.
- Escolha única ao entrar (tela abre sozinha no 1º login). Dados salvos no player e mantidos após a morte.
- **Árvore de habilidades** (tecla K): cada classe tem a sua, em 3 ramos x 3 níveis (cada nível exige o anterior do ramo). Mago/Clérigo/Druida: mana, poder e feitiços. Guerreiro: vida, dano e feitiços. Ladino: velocidade, dano/vel. de ataque e feitiços. Arqueiro: dano de flechas, chance de recuperar flecha, mobilidade. Cozinheiro: duração dos buffs, peixe raro, vida. Artesão: vida/dano/velocidade dos golens. Pontos: +1 por nível de XP, +3 por boss.
- **Livros/pergaminhos do Iron's removidos de TODOS os baús** (global loot modifier). Só vêm de bosses (pergaminho aleatório, nv 2–4) ou da árvore.
- **Novas magias**: Pele de Casca (Druida/natureza) e Grito de Guerra (Guerreiro/Clérigo).
- **Cozinheiro (classe)**: 6 peixes exclusivos por bioma (oceano quente/morno/gelado/profundo, rio, pântano). O Cozinheiro tem chance bem maior de fisgá-los (e cresce com o nível); outras classes só uma chance baixa. Defumador/fogueira cozinham. Comer cozido dá buff que escala com o nível de Cozinheiro. Receita do Ensopado de Peixe (tag `ironorigins:cooked_fish`).
- **Artesão de Golens (classe)**: peças por material (pedra→diamante) x slot (cabeça=armadura, torso=vida, braços=dano, pernas=velocidade) + núcleo (fogo/gelo/arcano). Só o Artesão usa a Varinha do Artesão de Golens (no chão). Materiais melhores exigem nível de Artesão; a árvore multiplica vida/dano/velocidade dos golens.
- **Itens de classe** (aba criativa "Iron Origins", todos com receita; mostram a classe no tooltip; +15% de dano corpo a corpo para a classe certa):
  - Arqueiro: Arco do Caçador, Arco Élfico (saque rápido), Arco Longo (dano alto, saque lento), Arco Flamejante (incendeia), Arco Glacial (lentidão)
  - Mago: Cajados de Aprendiz / Arcano / do Arquimago (mana + poder mágico na mão)
  - Guerreiro: Lâmina Rubra (rouba vida), Machado do Arauto da Guerra (enfraquece)
  - Clérigo: Maça Sagrada (queima mortos-vivos), Cetro Solar (botão direito cura aliados)
  - Ladino: Adaga das Sombras (cega), Adaga Venenosa (veneno)
  - Druida: Cajado Druídico, Cajado Verdejante (botão direito faz plantas crescerem)
  - Cozinheiro: Faca de Chef, Frigideira de Ferro (knockback), Vara do Pescador-Chef (+10% peixe raro), Ensopado de Peixe
  - Artesão: Martelo do Artesão (botão direito conserta golems em 40%)
- **Comando de teste** (op): `/ironorigins reset [jogador]` apaga raça/classe/árvore e reabre a tela de escolha.

## ANTES DE COMPILAR (importante)
Não consegui compilar nem testar aqui (sem rede). Verifique:
1. `build.gradle`: coordenada/versão do Iron's e URL do maven.
2. IDs de magias em `SkillTree.classSpells`/`PlayerClass` (ex.: `irons_spellbooks:fang_strike`, `guiding_bolt`) e IDs de bosses em `CommonEvents.IRON_BOSSES`.
3. API do Iron's mudou entre versões: `ISpellContainer.createScrollContainer`, `SpellRegistry.none()/getEnabledSpells()/SPELL_REGISTRY_KEY`, `AttributeRegistry.*`, e a assinatura de `AbstractSpell.onCast` nas magias novas.
4. Texturas são placeholders pixel-art gerados por código; troque em `assets/ironorigins/textures/item`.
5. Itens novos usam `BowItem`, `SwordItem`, `AxeItem`, `FishingRodItem`, `BoneMealItem.growCrop`, `LivingEntity.knockback` e `FoodProperties` — se o compilador reclamar de algum, é ajuste de assinatura de 1 linha em `items/`.
