package dev.ironorigins;

import dev.ironorigins.golem.ArchitectWand;
import dev.ironorigins.golem.GolemParts;
import dev.ironorigins.items.ClassItems;
import java.util.LinkedHashMap;
import java.util.Map;
import net.minecraft.world.food.FoodProperties;
import net.minecraft.world.item.Item;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModItems {
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, IronOrigins.MODID);
    public static final Map<Fish, RegistryObject<Item>> RAW = new LinkedHashMap<>(), COOKED = new LinkedHashMap<>();
    public static final RegistryObject<Item> WAND = ITEMS.register("architect_wand", ArchitectWand::new);

    static {
        ClassItems.register(ITEMS);
        for (Fish f : Fish.values()) {
            RAW.put(f, ITEMS.register("raw_" + f.id, () -> new Item(new Item.Properties().food(
                    new FoodProperties.Builder().nutrition(2).saturationMod(0.1F).build()))));
            COOKED.put(f, ITEMS.register("cooked_" + f.id, () -> new Item(new Item.Properties().food(
                    new FoodProperties.Builder().nutrition(7).saturationMod(0.8F).build()))));
        }
        for (GolemParts.Mat m : GolemParts.Mat.values())
            for (GolemParts.Slot s : GolemParts.Slot.values())
                ITEMS.register(m.id + "_" + s.id, () -> new GolemParts.PartItem(s, m));
        for (GolemParts.Core c : GolemParts.Core.values())
            ITEMS.register("core_" + c.id, () -> new GolemParts.CoreItem(c));
    }
}
