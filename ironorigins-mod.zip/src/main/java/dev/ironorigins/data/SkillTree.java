package dev.ironorigins.data;

import static dev.ironorigins.data.Bonus.add;
import static dev.ironorigins.data.Bonus.mult;

import io.redspace.ironsspellbooks.api.registry.AttributeRegistry;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;

/**
 * Árvore de habilidades POR CLASSE: 3 ramos x 3 níveis (cada nível exige o anterior do mesmo ramo).
 * Um nó pode dar atributos (bonuses), um feitiço (pergaminho) e/ou um "perk" (efeito especial lido por SkillTree.perk()).
 */
public final class SkillTree {
    private SkillTree() {}

    public static final int BRANCHES = 3, TIERS = 3;

    public record Node(String id, String name, String desc, int branch, int tier, int cost, String parent,
                       List<Bonus> bonuses, String spell, int spellLevel, String perk, double perkValue) {}

    private record Step(String id, String name, String desc, List<Bonus> bonuses, String spell, String perk, double perkValue) {}

    // ---- fábricas de passos ----
    private static Step stat(String id, String name, String desc, Bonus... b) { return new Step(id, name, desc, List.of(b), null, null, 0); }
    private static Step spell(String id, String spellId) { return new Step(id, null, "Concede o pergaminho do feitiço.", List.of(), spellId, null, 0); }
    private static Step perk(String id, String name, String desc, String perk, double v, Bonus... b) { return new Step(id, name, desc, List.of(b), null, perk, v); }

    private static void chain(List<Node> out, int branch, Step... steps) {
        String prev = null;
        for (int t = 0; t < steps.length; t++) {
            Step s = steps[t];
            out.add(new Node(s.id(), s.name(), s.desc(), branch, t, 1 + t, prev, s.bonuses(), s.spell(), s.spell() == null ? 0 : 1 + t, s.perk(), s.perkValue()));
            prev = s.id();
        }
    }

    /** Nome de cada ramo (coluna) da árvore. */
    public static String[] branchNames(PlayerClass c) {
        return switch (c) {
            case MAGE -> new String[] {"Reserva Arcana", "Poder Mágico", "Grimório"};
            case WARRIOR -> new String[] {"Vigor", "Brutalidade", "Comando"};
            case CLERIC -> new String[] {"Fé", "Bênção", "Milagres"};
            case ROGUE -> new String[] {"Agilidade", "Letalidade", "Sombras"};
            case ARCHER -> new String[] {"Precisão", "Aljava", "Caçada"};
            case DRUID -> new String[] {"Natureza", "Raízes", "Rituais"};
            case COOK -> new String[] {"Banquete", "Pesca", "Constituição"};
            case GOLEM_CRAFTER -> new String[] {"Engenharia", "Armamento", "Oficina"};
        };
    }

    private static List<Node> build(PlayerClass c) {
        List<Node> l = new ArrayList<>();
        switch (c) {
            case MAGE -> {
                chain(l, 0, stat("mana_1", "Reservas I", "+50 de mana máxima", add(AttributeRegistry.MAX_MANA, 50)),
                            stat("mana_2", "Reservas II", "+100 de mana máxima", add(AttributeRegistry.MAX_MANA, 100)),
                            stat("mana_3", "Reservas III", "+150 de mana máxima", add(AttributeRegistry.MAX_MANA, 150)));
                chain(l, 1, stat("power_1", "Foco Mágico I", "+5% de poder mágico", mult(AttributeRegistry.SPELL_POWER, 0.05)),
                            stat("power_2", "Foco Mágico II", "+10% de poder mágico", mult(AttributeRegistry.SPELL_POWER, 0.10)),
                            stat("power_3", "Foco Mágico III", "+15% de poder mágico", mult(AttributeRegistry.SPELL_POWER, 0.15)));
                chain(l, 2, spell("spell_0", "irons_spellbooks:magic_missile"), spell("spell_1", "irons_spellbooks:fireball"), spell("spell_2", "irons_spellbooks:lightning_bolt"));
            }
            case WARRIOR -> {
                chain(l, 0, stat("vigor_1", "Vigor I", "+4 de vida máxima", add(() -> Attributes.MAX_HEALTH, 4)),
                            stat("vigor_2", "Vigor II", "+4 de vida máxima", add(() -> Attributes.MAX_HEALTH, 4)),
                            stat("vigor_3", "Vigor III", "+6 de vida e +2 de armadura", add(() -> Attributes.MAX_HEALTH, 6), add(() -> Attributes.ARMOR, 2)));
                chain(l, 1, stat("brut_1", "Brutalidade I", "+1 de dano de ataque", add(() -> Attributes.ATTACK_DAMAGE, 1)),
                            stat("brut_2", "Brutalidade II", "+1 de dano de ataque", add(() -> Attributes.ATTACK_DAMAGE, 1)),
                            stat("brut_3", "Brutalidade III", "+2 de dano de ataque", add(() -> Attributes.ATTACK_DAMAGE, 2)));
                chain(l, 2, spell("spell_0", "irons_spellbooks:haste"), spell("spell_1", "ironorigins:war_cry"), spell("spell_2", "irons_spellbooks:blood_slash"));
            }
            case CLERIC -> {
                chain(l, 0, stat("faith_1", "Fé I", "+40 de mana máxima", add(AttributeRegistry.MAX_MANA, 40)),
                            stat("faith_2", "Fé II", "+60 de mana máxima", add(AttributeRegistry.MAX_MANA, 60)),
                            stat("faith_3", "Fé III", "+100 de mana máxima", add(AttributeRegistry.MAX_MANA, 100)));
                chain(l, 1, stat("bless_1", "Bênção I", "+2 de vida máxima", add(() -> Attributes.MAX_HEALTH, 2)),
                            stat("bless_2", "Bênção II", "+2 de vida e +4% de poder", add(() -> Attributes.MAX_HEALTH, 2), mult(AttributeRegistry.SPELL_POWER, 0.04)),
                            stat("bless_3", "Bênção III", "+4 de vida e +6% de poder", add(() -> Attributes.MAX_HEALTH, 4), mult(AttributeRegistry.SPELL_POWER, 0.06)));
                chain(l, 2, spell("spell_0", "irons_spellbooks:heal"), spell("spell_1", "irons_spellbooks:guiding_bolt"), spell("spell_2", "ironorigins:war_cry"));
            }
            case ROGUE -> {
                chain(l, 0, stat("agi_1", "Passo Leve I", "+4% de velocidade", mult(() -> Attributes.MOVEMENT_SPEED, 0.04)),
                            stat("agi_2", "Passo Leve II", "+4% de velocidade", mult(() -> Attributes.MOVEMENT_SPEED, 0.04)),
                            stat("agi_3", "Passo Leve III", "+5% de velocidade", mult(() -> Attributes.MOVEMENT_SPEED, 0.05)));
                chain(l, 1, stat("lethal_1", "Lâmina Afiada I", "+1 de dano, +5% vel. de ataque", add(() -> Attributes.ATTACK_DAMAGE, 1), mult(() -> Attributes.ATTACK_SPEED, 0.05)),
                            stat("lethal_2", "Lâmina Afiada II", "+1 de dano, +5% vel. de ataque", add(() -> Attributes.ATTACK_DAMAGE, 1), mult(() -> Attributes.ATTACK_SPEED, 0.05)),
                            stat("lethal_3", "Lâmina Afiada III", "+1 de dano, +10% vel. de ataque", add(() -> Attributes.ATTACK_DAMAGE, 1), mult(() -> Attributes.ATTACK_SPEED, 0.10)));
                chain(l, 2, spell("spell_0", "irons_spellbooks:invisibility"), spell("spell_1", "irons_spellbooks:blink"), spell("spell_2", "irons_spellbooks:teleport"));
            }
            case ARCHER -> {
                chain(l, 0, perk("aim_1", "Mira I", "+10% de dano de flechas", "arrow_damage", 0.10),
                            perk("aim_2", "Mira II", "+10% de dano de flechas", "arrow_damage", 0.10),
                            perk("aim_3", "Mira III", "+15% de dano de flechas", "arrow_damage", 0.15));
                chain(l, 1, perk("quiver_1", "Aljava Farta I", "10% de chance de recuperar a flecha", "arrow_save", 0.10),
                            perk("quiver_2", "Aljava Farta II", "+10% de chance de recuperar a flecha", "arrow_save", 0.10),
                            perk("quiver_3", "Aljava Farta III", "+15% de chance de recuperar a flecha", "arrow_save", 0.15));
                chain(l, 2, stat("hunt_1", "Passo Silencioso", "+4% de velocidade", mult(() -> Attributes.MOVEMENT_SPEED, 0.04)),
                            stat("hunt_2", "Pele Curtida", "+2 de vida e +1 de armadura", add(() -> Attributes.MAX_HEALTH, 2), add(() -> Attributes.ARMOR, 1)),
                            stat("hunt_3", "Olhar de Águia", "+4% de velocidade e +2 de vida", mult(() -> Attributes.MOVEMENT_SPEED, 0.04), add(() -> Attributes.MAX_HEALTH, 2)));
            }
            case DRUID -> {
                chain(l, 0, stat("nature_1", "Voz da Natureza I", "+5% de poder de natureza", mult(AttributeRegistry.NATURE_SPELL_POWER, 0.05)),
                            stat("nature_2", "Voz da Natureza II", "+5% de poder de natureza", mult(AttributeRegistry.NATURE_SPELL_POWER, 0.05)),
                            stat("nature_3", "Voz da Natureza III", "+10% de poder de natureza", mult(AttributeRegistry.NATURE_SPELL_POWER, 0.10)));
                chain(l, 1, stat("roots_1", "Seiva I", "+40 de mana máxima", add(AttributeRegistry.MAX_MANA, 40)),
                            stat("roots_2", "Seiva II", "+60 de mana máxima", add(AttributeRegistry.MAX_MANA, 60)),
                            stat("roots_3", "Seiva III", "+80 de mana máxima", add(AttributeRegistry.MAX_MANA, 80)));
                chain(l, 2, spell("spell_0", "ironorigins:bark_skin"), spell("spell_1", "irons_spellbooks:root"), spell("spell_2", "irons_spellbooks:poison_arrow"));
            }
            case COOK -> {
                chain(l, 0, perk("feast_1", "Tempero I", "+25% de duração dos buffs de peixe", "buff_duration", 0.25),
                            perk("feast_2", "Tempero II", "+25% de duração dos buffs de peixe", "buff_duration", 0.25),
                            perk("feast_3", "Tempero III", "+50% de duração dos buffs de peixe", "buff_duration", 0.50));
                chain(l, 1, perk("fish_1", "Isca Refinada I", "+5% de chance de peixe raro, +1 sorte", "rare_fish", 0.05, add(() -> Attributes.LUCK, 1)),
                            perk("fish_2", "Isca Refinada II", "+5% de chance de peixe raro, +1 sorte", "rare_fish", 0.05, add(() -> Attributes.LUCK, 1)),
                            perk("fish_3", "Isca Refinada III", "+10% de chance de peixe raro, +1 sorte", "rare_fish", 0.10, add(() -> Attributes.LUCK, 1)));
                chain(l, 2, stat("body_1", "Bom de Garfo I", "+2 de vida máxima", add(() -> Attributes.MAX_HEALTH, 2)),
                            stat("body_2", "Bom de Garfo II", "+2 de vida máxima", add(() -> Attributes.MAX_HEALTH, 2)),
                            stat("body_3", "Bom de Garfo III", "+4 de vida e +1 de armadura", add(() -> Attributes.MAX_HEALTH, 4), add(() -> Attributes.ARMOR, 1)));
            }
            case GOLEM_CRAFTER -> {
                chain(l, 0, perk("eng_1", "Estrutura I", "Golems com +15% de vida", "golem_hp", 0.15),
                            perk("eng_2", "Estrutura II", "Golems com +15% de vida", "golem_hp", 0.15),
                            perk("eng_3", "Estrutura III", "Golems com +20% de vida", "golem_hp", 0.20));
                chain(l, 1, perk("arm_1", "Punhos I", "Golems com +10% de dano", "golem_dmg", 0.10),
                            perk("arm_2", "Punhos II", "Golems com +10% de dano", "golem_dmg", 0.10),
                            perk("arm_3", "Punhos III", "Golems com +15% de dano", "golem_dmg", 0.15));
                chain(l, 2, perk("shop_1", "Engrenagens I", "Golems +5% de velocidade, você +1 armadura", "golem_speed", 0.05, add(() -> Attributes.ARMOR, 1)),
                            perk("shop_2", "Engrenagens II", "Golems +5% de velocidade, você +1 armadura", "golem_speed", 0.05, add(() -> Attributes.ARMOR, 1)),
                            perk("shop_3", "Engrenagens III", "Golems +10% de velocidade, +2 armadura e +4 vida", "golem_speed", 0.10, add(() -> Attributes.ARMOR, 2), add(() -> Attributes.MAX_HEALTH, 4)));
            }
        }
        return l;
    }

    private static final Map<PlayerClass, List<Node>> CACHE = new ConcurrentHashMap<>();

    public static List<Node> nodes(PlayerClass c) { return CACHE.computeIfAbsent(c, SkillTree::build); }

    public static Node find(PlayerClass c, String id) {
        for (Node n : nodes(c)) if (n.id().equals(id)) return n;
        return null;
    }

    /** Soma dos valores do perk `key` nos nós desbloqueados pelo jogador (0 se não tiver). */
    public static double perk(Player p, String key) {
        PlayerClass c = PlayerData.cls(p);
        if (c == null) return 0;
        Set<String> u = PlayerData.unlocked(p);
        double sum = 0;
        for (Node n : nodes(c)) if (key.equals(n.perk()) && u.contains(n.id())) sum += n.perkValue();
        return sum;
    }
}
