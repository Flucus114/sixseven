package dev.ironorigins.items;

import static dev.ironorigins.data.Bonus.add;
import static dev.ironorigins.data.Bonus.mult;

import dev.ironorigins.data.PlayerClass;
import io.redspace.ironsspellbooks.api.registry.AttributeRegistry;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.function.Supplier;
import net.minecraft.core.BlockPos;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.MobType;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.BoneMealItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.RegistryObject;

/** Itens exclusivos de cada classe. Para adicionar um novo: registre aqui, adicione texturas/modelo/receita/lang. */
public final class ClassItems {
    private ClassItems() {}

    public static final Map<String, RegistryObject<Item>> BY_ID = new LinkedHashMap<>();

    public static ItemStack stack(String id) { return new ItemStack(BY_ID.get(id).get()); }
    public static ItemStack stack(String id, int n) { return new ItemStack(BY_ID.get(id).get(), n); }

    private static void reg(DeferredRegister<Item> r, String id, Supplier<Item> s) { BY_ID.put(id, r.register(id, s)); }

    private static void effect(LivingEntity t, net.minecraft.world.effect.MobEffect e, int ticks, int amp) { t.addEffect(new MobEffectInstance(e, ticks, amp)); }

    public static void register(DeferredRegister<Item> r) {
        // ---------------- ARQUEIRO: arcos (durabilidade, velocidade de saque, dano extra, efeito) ----------------
        reg(r, "hunter_bow", () -> new ClassBow(480, 1.15F, 0.5F, ClassBow.Special.NONE));
        reg(r, "elven_bow", () -> new ClassBow(620, 1.45F, 0.0F, ClassBow.Special.NONE));
        reg(r, "longbow", () -> new ClassBow(700, 0.80F, 2.5F, ClassBow.Special.NONE));
        reg(r, "flame_bow", () -> new ClassBow(520, 1.0F, 1.0F, ClassBow.Special.FIRE));
        reg(r, "frost_bow", () -> new ClassBow(520, 1.0F, 1.0F, ClassBow.Special.FROST));

        // ---------------- MAGO: cajados (mana e poder mágico enquanto empunhados) ----------------
        reg(r, "apprentice_staff", () -> new ClassStaff(PlayerClass.MAGE, "apprentice", 300, 2, add(AttributeRegistry.MAX_MANA, 30), mult(AttributeRegistry.SPELL_POWER, 0.05)));
        reg(r, "arcane_staff", () -> new ClassStaff(PlayerClass.MAGE, "arcane", 600, 3, add(AttributeRegistry.MAX_MANA, 60), mult(AttributeRegistry.SPELL_POWER, 0.10)));
        reg(r, "archmage_staff", () -> new ClassStaff(PlayerClass.MAGE, "archmage", 1000, 4, add(AttributeRegistry.MAX_MANA, 110), mult(AttributeRegistry.SPELL_POWER, 0.18)));

        // ---------------- GUERREIRO ----------------
        reg(r, "crimson_blade", () -> new ClassSword(PlayerClass.WARRIOR, ClassTier.CRIMSON, 3, -2.4F, (t, a) -> a.heal(1.5F)));            // rouba vida
        reg(r, "warbringer_axe", () -> new ClassAxe(PlayerClass.WARRIOR, ClassTier.STEEL, 6.0F, -3.2F, (t, a) -> effect(t, MobEffects.WEAKNESS, 80, 0))); // enfraquece

        // ---------------- CLÉRIGO ----------------
        reg(r, "holy_mace", () -> new ClassSword(PlayerClass.CLERIC, ClassTier.HOLY, 3, -2.8F, (t, a) -> {                                // fogo sagrado em mortos-vivos
            if (t.getMobType() == MobType.UNDEAD) t.setSecondsOnFire(6);
        }));
        reg(r, "sun_scepter", () -> new ClassStaff(PlayerClass.CLERIC, "sun", 400, 2, add(AttributeRegistry.MAX_MANA, 40), mult(AttributeRegistry.SPELL_POWER, 0.08)) {
            @Override public InteractionResultHolder<ItemStack> use(Level level, Player p, InteractionHand hand) {                           // botão direito: cura você e aliados próximos
                ItemStack st = p.getItemInHand(hand);
                if (p.getCooldowns().isOnCooldown(this)) return InteractionResultHolder.pass(st);
                if (!level.isClientSide) {
                    p.heal(6.0F);
                    for (Player o : level.getEntitiesOfClass(Player.class, p.getBoundingBox().inflate(6))) if (o != p) o.heal(4.0F);
                    p.getCooldowns().addCooldown(this, 300);
                    st.hurtAndBreak(1, p, e -> e.broadcastBreakEvent(hand));
                }
                return InteractionResultHolder.sidedSuccess(st, level.isClientSide);
            }
        });

        // ---------------- LADINO: adagas rápidas ----------------
        reg(r, "shadow_dagger", () -> new ClassSword(PlayerClass.ROGUE, ClassTier.DAGGER, 2, -1.4F, (t, a) -> effect(t, MobEffects.BLINDNESS, 40, 0)));
        reg(r, "venom_dagger", () -> new ClassSword(PlayerClass.ROGUE, ClassTier.DAGGER, 2, -1.5F, (t, a) -> effect(t, MobEffects.POISON, 80, 0)));

        // ---------------- DRUIDA ----------------
        reg(r, "druid_staff", () -> new ClassStaff(PlayerClass.DRUID, "druid", 400, 2, add(AttributeRegistry.MAX_MANA, 30), mult(AttributeRegistry.NATURE_SPELL_POWER, 0.10)));
        reg(r, "verdant_staff", () -> new ClassStaff(PlayerClass.DRUID, "verdant", 700, 3, add(AttributeRegistry.MAX_MANA, 50), mult(AttributeRegistry.NATURE_SPELL_POWER, 0.16)) {
            @Override public InteractionResult useOn(UseOnContext ctx) {                                                                      // botão direito: faz plantas crescerem
                Level level = ctx.getLevel();
                BlockPos pos = ctx.getClickedPos();
                if (level.isClientSide) return InteractionResult.SUCCESS;
                if (BoneMealItem.growCrop(new ItemStack(Items.BONE_MEAL), level, pos)) {
                    level.levelEvent(1505, pos, 15);
                    if (ctx.getPlayer() != null) ctx.getItemInHand().hurtAndBreak(1, ctx.getPlayer(), e -> e.broadcastBreakEvent(ctx.getHand()));
                    return InteractionResult.CONSUME;
                }
                return InteractionResult.PASS;
            }
        });

        // ---------------- COZINHEIRO ----------------
        reg(r, "chef_knife", () -> new ClassSword(PlayerClass.COOK, ClassTier.CULINARY, 1, -1.8F, null));
        reg(r, "iron_skillet", () -> new ClassSword(PlayerClass.COOK, ClassTier.CULINARY, 3, -3.0F, (t, a) -> {                           // frigideirada: empurra forte
            t.knockback(0.9, a.getX() - t.getX(), a.getZ() - t.getZ());
            a.level().playSound(null, t.blockPosition(), SoundEvents.ANVIL_LAND, net.minecraft.sounds.SoundSource.PLAYERS, 0.4F, 1.6F);
        }));
        reg(r, "angler_rod", AnglerRod::new);
        reg(r, "fish_stew", FishStew::new);

        // ---------------- ARTESÃO DE GOLENS ----------------
        reg(r, "artisan_hammer", ArtisanHammer::new);
    }
}
