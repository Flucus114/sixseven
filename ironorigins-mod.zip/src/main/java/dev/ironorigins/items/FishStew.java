package dev.ironorigins.items;

import dev.ironorigins.data.PlayerClass;
import net.minecraft.world.food.FoodProperties;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;

/** Ensopado de Peixe: sopa que devolve a tigela. O buff é dado em CommonEvents#eaten (mais forte para o Cozinheiro). */
public class FishStew extends Item implements ClassGear {
    public FishStew() {
        super(new Item.Properties().stacksTo(1).food(new FoodProperties.Builder().nutrition(11).saturationMod(1.0F).build()));
    }

    @Override public PlayerClass gearClass() { return PlayerClass.COOK; }

    @Override public ItemStack finishUsingItem(ItemStack stack, Level level, LivingEntity entity) {
        ItemStack r = super.finishUsingItem(stack, level, entity);
        return entity instanceof Player p && p.getAbilities().instabuild ? r : new ItemStack(Items.BOWL);
    }
}
