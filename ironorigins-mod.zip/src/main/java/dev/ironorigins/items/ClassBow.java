package dev.ironorigins.items;

import dev.ironorigins.data.PlayerClass;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.BowItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

/**
 * Arco de classe. drawSpeed multiplica a velocidade de saque, bonusDamage soma ao dano base da flecha
 * (aplicado em CommonEvents#arrowJoin), special = efeito da flecha (fogo/gelo).
 */
public class ClassBow extends BowItem implements ClassGear {
    public enum Special { NONE, FIRE, FROST }

    private final float drawSpeed, bonusDamage;
    private final Special special;

    public ClassBow(int durability, float drawSpeed, float bonusDamage, Special special) {
        super(new Item.Properties().durability(durability));
        this.drawSpeed = drawSpeed; this.bonusDamage = bonusDamage; this.special = special;
    }

    public float drawSpeed() { return drawSpeed; }
    public float bonusDamage() { return bonusDamage; }
    public Special special() { return special; }

    @Override public PlayerClass gearClass() { return PlayerClass.ARCHER; }

    /** Saque mais rápido/lento: "adianta" ou "atrasa" o tempo de carga antes de o BowItem calcular a força. */
    @Override public void releaseUsing(ItemStack stack, Level level, LivingEntity user, int timeLeft) {
        int max = getUseDuration(stack);
        int charged = Math.min(max, (int) ((max - timeLeft) * drawSpeed));
        super.releaseUsing(stack, level, user, max - charged);
    }
}
