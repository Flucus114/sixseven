package dev.ironorigins.items;

import dev.ironorigins.data.PlayerClass;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.AxeItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Tier;

public class ClassAxe extends AxeItem implements ClassGear {
    private final PlayerClass cls;
    private final ClassSword.OnHit onHit;

    public ClassAxe(PlayerClass cls, Tier tier, float dmg, float attackSpeed, ClassSword.OnHit onHit) {
        super(tier, dmg, attackSpeed, new Item.Properties());
        this.cls = cls;
        this.onHit = onHit;
    }

    @Override public PlayerClass gearClass() { return cls; }

    @Override public boolean hurtEnemy(ItemStack stack, LivingEntity target, LivingEntity attacker) {
        boolean r = super.hurtEnemy(stack, target, attacker);
        if (onHit != null) onHit.hit(target, attacker);
        return r;
    }
}
