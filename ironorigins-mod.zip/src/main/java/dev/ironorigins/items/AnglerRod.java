package dev.ironorigins.items;

import dev.ironorigins.data.PlayerClass;
import net.minecraft.world.item.FishingRodItem;
import net.minecraft.world.item.Item;

/** Vara do Pescador-Chef: aumenta a chance de peixe raro do Cozinheiro (ver CommonEvents#fished). */
public class AnglerRod extends FishingRodItem implements ClassGear {
    public AnglerRod() { super(new Item.Properties().durability(250)); }
    @Override public PlayerClass gearClass() { return PlayerClass.COOK; }
}
