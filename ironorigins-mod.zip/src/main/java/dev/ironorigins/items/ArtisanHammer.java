package dev.ironorigins.items;

import dev.ironorigins.data.PlayerClass;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.animal.IronGolem;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.SwordItem;

/** Martelo do Artesão: arma pesada e, com botão direito num golem de ferro/customizado, conserta 40% da vida. */
public class ArtisanHammer extends SwordItem implements ClassGear {
    public ArtisanHammer() { super(ClassTier.ARTISAN, 4, -3.2F, new Item.Properties()); }

    @Override public PlayerClass gearClass() { return PlayerClass.GOLEM_CRAFTER; }

    @Override public InteractionResult interactLivingEntity(ItemStack stack, Player player, LivingEntity target, InteractionHand hand) {
        if (!(target instanceof IronGolem g) || g.getHealth() >= g.getMaxHealth()) return InteractionResult.PASS;
        if (!player.level().isClientSide) {
            g.heal(g.getMaxHealth() * 0.4F);
            g.playSound(SoundEvents.IRON_GOLEM_REPAIR, 1.0F, 1.0F);
            stack.hurtAndBreak(1, player, p -> p.broadcastBreakEvent(hand));
        }
        return InteractionResult.sidedSuccess(player.level().isClientSide);
    }
}
