package dev.ironorigins.items;

import dev.ironorigins.data.PlayerClass;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.SwordItem;
import net.minecraft.world.item.Tier;

/** Arma corpo a corpo de classe (espada/adaga/maça/faca/frigideira/martelo) com efeito ao acertar. */
public class ClassSword extends SwordItem implements ClassGear {
    @FunctionalInterface public interface OnHit { void hit(LivingEntity target, LivingEntity attacker); }

    private final PlayerClass cls;
    private final OnHit onHit;

    public ClassSword(PlayerClass cls, Tier tier, int dmgMod, float attackSpeed, OnHit onHit) {
        super(tier, dmgMod, attackSpeed, new Item.Properties());
        this.cls = cls;
        this.onHit = onHit;
    }

    @Override public PlayerClass gearClass() { return cls; }

    @Override public boolean hurtEnemy(ItemStack stack, LivingEntity target, LivingEntity attacker) {
        boolean r = super.hurtEnemy(stack, target, attacker);
        if (onHit != null) onHit.hit(target, attacker);
        return r;
    }
}
