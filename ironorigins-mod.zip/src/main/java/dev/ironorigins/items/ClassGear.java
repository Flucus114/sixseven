package dev.ironorigins.items;

import dev.ironorigins.data.PlayerClass;

/** Marca um item como equipamento de uma classe: mostra a classe no tooltip e dá +15% de dano à classe certa. */
public interface ClassGear {
    PlayerClass gearClass();
}
