package dev.ironorigins.items;

import com.google.common.collect.ImmutableMultimap;
import com.google.common.collect.Multimap;
import dev.ironorigins.data.Bonus;
import dev.ironorigins.data.PlayerClass;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.UUID;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;

/** Cajado/cetro: enquanto na mão principal dá os bônus (mana, poder mágico...). Subclasses podem sobrescrever use/useOn. */
public class ClassStaff extends Item implements ClassGear {
    private final PlayerClass cls;
    private final String key;
    private final double melee;
    private final List<Bonus> bonuses;

    public ClassStaff(PlayerClass cls, String key, int durability, double melee, Bonus... bonuses) {
        super(new Item.Properties().durability(durability));
        this.cls = cls; this.key = key; this.melee = melee; this.bonuses = List.of(bonuses);
    }

    @Override public PlayerClass gearClass() { return cls; }

    @Override public Multimap<Attribute, AttributeModifier> getAttributeModifiers(EquipmentSlot slot, ItemStack stack) {
        if (slot != EquipmentSlot.MAINHAND) return super.getAttributeModifiers(slot, stack);
        ImmutableMultimap.Builder<Attribute, AttributeModifier> b = ImmutableMultimap.builder();
        b.put(Attributes.ATTACK_DAMAGE, new AttributeModifier(BASE_ATTACK_DAMAGE_UUID, "Weapon modifier", melee, AttributeModifier.Operation.ADDITION));
        b.put(Attributes.ATTACK_SPEED, new AttributeModifier(BASE_ATTACK_SPEED_UUID, "Weapon modifier", -2.8, AttributeModifier.Operation.ADDITION));
        for (int i = 0; i < bonuses.size(); i++) {
            Bonus bn = bonuses.get(i);
            UUID id = UUID.nameUUIDFromBytes(("ironorigins:staff_" + key + "_" + i).getBytes(StandardCharsets.UTF_8));
            b.put(bn.attr().get(), new AttributeModifier(id, "ironorigins_staff_" + key, bn.amount(), bn.op()));
        }
        return b.build();
    }
}
