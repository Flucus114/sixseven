package dev.ironorigins.items;

import java.util.function.Supplier;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.Tier;
import net.minecraft.world.item.crafting.Ingredient;

/** Materiais das armas de classe. Dano total = 1 + attackDamageBonus + modificador da arma. */
public enum ClassTier implements Tier {
    DAGGER(400, 6.0F, 0.0F, 1, 18, () -> Ingredient.of(Items.IRON_INGOT)),
    STEEL(800, 6.0F, 2.0F, 2, 14, () -> Ingredient.of(Items.IRON_INGOT)),
    CRIMSON(1000, 6.0F, 3.0F, 2, 14, () -> Ingredient.of(Items.IRON_INGOT)),
    HOLY(650, 6.0F, 2.0F, 2, 22, () -> Ingredient.of(Items.GOLD_INGOT)),
    CULINARY(500, 6.0F, 1.0F, 1, 12, () -> Ingredient.of(Items.IRON_INGOT)),
    ARTISAN(900, 6.0F, 2.0F, 2, 12, () -> Ingredient.of(Items.IRON_INGOT, Items.COPPER_INGOT));

    private final int uses, level, enchant;
    private final float speed, damage;
    private final Supplier<Ingredient> repair;

    ClassTier(int uses, float speed, float damage, int level, int enchant, Supplier<Ingredient> repair) {
        this.uses = uses; this.speed = speed; this.damage = damage; this.level = level; this.enchant = enchant; this.repair = repair;
    }

    @Override public int getUses() { return uses; }
    @Override public float getSpeed() { return speed; }
    @Override public float getAttackDamageBonus() { return damage; }
    @Override public int getLevel() { return level; }
    @Override public int getEnchantmentValue() { return enchant; }
    @Override public Ingredient getRepairIngredient() { return repair.get(); }
}
