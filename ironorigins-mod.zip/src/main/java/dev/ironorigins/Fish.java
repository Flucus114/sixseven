package dev.ironorigins;

import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffects;

/** Cada peixe só aparece num tipo de bioma (ver CommonEvents#fished). */
public enum Fish {
    CORAL_SNAPPER("coral_snapper", "warm_ocean", MobEffects.REGENERATION),
    SUN_BASS("sun_bass", "lukewarm", MobEffects.MOVEMENT_SPEED),
    FROST_CHAR("frost_char", "frozen", MobEffects.DAMAGE_RESISTANCE),
    ABYSS_LANTERN("abyss_lantern", "deep_ocean", MobEffects.NIGHT_VISION),
    RIVER_TROUT("river_trout", "river", MobEffects.JUMP),
    BOG_EEL("bog_eel", "swamp", MobEffects.DAMAGE_BOOST);

    public final String id, biomeKey;
    public final MobEffect effect;
    Fish(String id, String biomeKey, MobEffect e) { this.id = id; this.biomeKey = biomeKey; this.effect = e; }

    /** Ordem importa: "lukewarm" e "frozen" antes de "warm"/"ocean". */
    public static Fish forBiome(String path) {
        if (path.contains("frozen") || path.contains("cold_ocean")) return FROST_CHAR;
        if (path.contains("lukewarm")) return SUN_BASS;
        if (path.equals("warm_ocean")) return CORAL_SNAPPER;
        if (path.equals("deep_ocean")) return ABYSS_LANTERN;
        if (path.contains("river")) return RIVER_TROUT;
        if (path.contains("swamp")) return BOG_EEL;
        return null;
    }
}
