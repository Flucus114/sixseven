package dev.ironorigins.golem;

import net.minecraft.world.item.Item;

/** Peças do Arquiteto de Golens: cada slot usa uma stat diferente do material. */
public final class GolemParts {
    private GolemParts() {}

    public enum Slot {
        HEAD("head"), TORSO("torso"), ARMS("arms"), LEGS("legs");
        public final String id;
        Slot(String id) { this.id = id; }
    }

    /** level = nível de Arquiteto necessário. hp/dmg/armor são somados ao golem; speed é multiplicador. */
    public enum Mat {
        STONE("stone", 0, -40, -6, 0, -0.10, "minecraft:cobblestone"),
        COPPER("copper", 1, -15, -2, 0, 0.00, "minecraft:copper_ingot"),
        IRON("iron", 2, 0, 0, 2, -0.05, "minecraft:iron_ingot"),
        AMETHYST("amethyst", 4, 40, 6, 4, 0.05, "minecraft:amethyst_shard"),
        DIAMOND("diamond", 6, 100, 15, 8, 0.00, "minecraft:diamond");

        public final String id, ingredient;
        public final int level;
        public final double hp, dmg, armor, speed;
        Mat(String id, int level, double hp, double dmg, double armor, double speed, String ingredient) {
            this.id = id; this.level = level; this.hp = hp; this.dmg = dmg; this.armor = armor; this.speed = speed; this.ingredient = ingredient;
        }
        public static Mat byId(String id) { for (Mat m : values()) if (m.id.equals(id)) return m; return null; }
    }

    public enum Core {
        FIRE("fire"), FROST("frost"), ARCANE("arcane");
        public final String id;
        Core(String id) { this.id = id; }
        public static Core byId(String id) { for (Core c : values()) if (c.id.equals(id)) return c; return null; }
    }

    public static class PartItem extends Item {
        public final Slot slot; public final Mat mat;
        public PartItem(Slot s, Mat m) { super(new Item.Properties().stacksTo(16)); this.slot = s; this.mat = m; }
    }

    public static class CoreItem extends Item {
        public final Core core;
        public CoreItem(Core c) { super(new Item.Properties().stacksTo(16)); this.core = c; }
    }
}
