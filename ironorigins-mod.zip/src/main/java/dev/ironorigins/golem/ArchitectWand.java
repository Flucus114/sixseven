package dev.ironorigins.golem;

import dev.ironorigins.Logic;
import dev.ironorigins.ModEntities;
import dev.ironorigins.data.PlayerClass;
import dev.ironorigins.data.PlayerData;
import dev.ironorigins.data.SkillTree;
import dev.ironorigins.items.ClassGear;
import dev.ironorigins.golem.GolemParts.*;
import java.util.ArrayList;
import java.util.EnumMap;
import java.util.List;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.ai.attributes.AttributeModifier.Operation;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.context.UseOnContext;

/** Varinha do Artesão de Golens (só a classe Artesão consegue usar): usa no chão. Consome a 1ª peça de cada slot do inventário (você escolhe a ordem) + núcleo opcional. */
public class ArchitectWand extends Item implements ClassGear {
    public ArchitectWand() { super(new Item.Properties().stacksTo(1)); }

    @Override public PlayerClass gearClass() { return PlayerClass.GOLEM_CRAFTER; }

    @Override public InteractionResult useOn(UseOnContext ctx) {
        Player p = ctx.getPlayer();
        if (ctx.getLevel().isClientSide || !(p instanceof ServerPlayer sp)) return InteractionResult.SUCCESS;
        if (PlayerData.cls(sp) != PlayerClass.GOLEM_CRAFTER) { sp.displayClientMessage(Component.translatable("msg.ironorigins.golem_class"), true); return InteractionResult.FAIL; }
        EnumMap<Slot, Mat> parts = new EnumMap<>(Slot.class);
        Core core = null;
        List<ItemStack> used = new ArrayList<>();
        for (ItemStack s : sp.getInventory().items) {
            if (s.getItem() instanceof PartItem pi && !parts.containsKey(pi.slot)) { parts.put(pi.slot, pi.mat); used.add(s); }
            else if (s.getItem() instanceof CoreItem ci && core == null) { core = ci.core; used.add(s); }
        }
        if (parts.size() < 4) { sp.displayClientMessage(Component.translatable("msg.ironorigins.golem_missing"), true); return InteractionResult.FAIL; }
        int lvl = PlayerData.level(sp, "golem");
        for (Mat m : parts.values()) if (m.level > lvl) {
            sp.displayClientMessage(Component.translatable("msg.ironorigins.golem_level", m.level), true);
            return InteractionResult.FAIL;
        }
        used.forEach(s -> s.shrink(1));
        CustomGolem g = ModEntities.GOLEM.get().create(ctx.getLevel());
        BlockPos pos = ctx.getClickedPos().relative(ctx.getClickedFace());
        g.moveTo(pos.getX() + 0.5, pos.getY(), pos.getZ() + 0.5, sp.getYRot(), 0);
        g.setPlayerCreated(true);
        g.setParts(parts, core);
        // perks da árvore do Artesão: multiplicam o resultado final dos stats do golem
        Logic.put(g, () -> Attributes.MAX_HEALTH, "golem_perk_hp", SkillTree.perk(sp, "golem_hp"), Operation.MULTIPLY_TOTAL);
        Logic.put(g, () -> Attributes.ATTACK_DAMAGE, "golem_perk_dmg", SkillTree.perk(sp, "golem_dmg"), Operation.MULTIPLY_TOTAL);
        Logic.put(g, () -> Attributes.MOVEMENT_SPEED, "golem_perk_speed", SkillTree.perk(sp, "golem_speed"), Operation.MULTIPLY_TOTAL);
        g.setHealth(g.getMaxHealth());
        ctx.getLevel().addFreshEntity(g);
        PlayerData.addXp(sp, "golem", 15);
        Logic.sync(sp);
        return InteractionResult.CONSUME;
    }
}
