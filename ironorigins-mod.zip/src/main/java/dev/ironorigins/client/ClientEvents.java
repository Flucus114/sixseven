package dev.ironorigins.client;

import com.mojang.blaze3d.platform.InputConstants;
import dev.ironorigins.IronOrigins;
import dev.ironorigins.ModEntities;
import dev.ironorigins.items.ClassBow;
import dev.ironorigins.items.ClassItems;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.renderer.item.ItemProperties;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.FishingRodItem;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;
import net.minecraft.client.renderer.entity.IronGolemRenderer;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.lwjgl.glfw.GLFW;

public final class ClientEvents {
    public static final KeyMapping TREE = new KeyMapping("key.ironorigins.tree", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_K, "key.categories.ironorigins");

    @Mod.EventBusSubscriber(modid = IronOrigins.MODID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
    public static class ModBus {
        @SubscribeEvent public static void keys(RegisterKeyMappingsEvent e) { e.register(TREE); }
        /** Animações dos itens: arcos de classe (puxar a corda respeitando a velocidade de saque) e vara do pescador (lançada). */
        @SubscribeEvent public static void setup(FMLClientSetupEvent e) {
            e.enqueueWork(() -> ClassItems.BY_ID.values().forEach(o -> {
                if (o.get() instanceof ClassBow bow) {
                    ItemProperties.register(bow, new ResourceLocation("pull"), (stack, level, ent, seed) ->
                            ent == null || ent.getUseItem() != stack ? 0.0F : (float) (stack.getUseDuration() - ent.getUseItemRemainingTicks()) * bow.drawSpeed() / 20.0F);
                    ItemProperties.register(bow, new ResourceLocation("pulling"), (stack, level, ent, seed) ->
                            ent != null && ent.isUsingItem() && ent.getUseItem() == stack ? 1.0F : 0.0F);
                } else if (o.get() instanceof FishingRodItem rod) {
                    ItemProperties.register(rod, new ResourceLocation("cast"), (stack, level, ent, seed) -> {
                        if (ent == null) return 0.0F;
                        boolean main = ent.getMainHandItem() == stack;
                        boolean off = ent.getOffhandItem() == stack && !(ent.getMainHandItem().getItem() instanceof FishingRodItem);
                        return (main || off) && ent instanceof Player p && p.fishing != null ? 1.0F : 0.0F;
                    });
                }
            }));
        }
        @SubscribeEvent public static void renderers(EntityRenderersEvent.RegisterRenderers e) {
            e.registerEntityRenderer(ModEntities.GOLEM.get(), IronGolemRenderer::new);
        }
    }

    @Mod.EventBusSubscriber(modid = IronOrigins.MODID, value = Dist.CLIENT)
    public static class ForgeBus {
        @SubscribeEvent public static void tick(TickEvent.ClientTickEvent e) {
            if (e.phase == TickEvent.Phase.END && TREE.consumeClick()) ClientHooks.openTree();
        }
    }
}
