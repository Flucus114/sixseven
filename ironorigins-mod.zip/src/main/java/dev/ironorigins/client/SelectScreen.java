package dev.ironorigins.client;

import dev.ironorigins.data.PlayerClass;
import dev.ironorigins.data.Race;
import dev.ironorigins.net.Net;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

public class SelectScreen extends Screen {
    private int race = 0, cls = 0;

    public SelectScreen() { super(Component.translatable("screen.ironorigins.select")); }

    @Override protected void init() {
        int cx = width / 2;
        int top = 54, step = 20;
        Race[] rs = Race.values();
        for (int i = 0; i < rs.length; i++) {
            final int idx = i;
            addRenderableWidget(Button.builder(Component.literal(race == i ? "> " : "").append(Component.translatable("race.ironorigins." + rs[i].id)),
                    b -> { race = idx; rebuildWidgets(); }).bounds(cx - 210, top + i * step, 200, 18).build());
        }
        PlayerClass[] cs = PlayerClass.values();
        for (int i = 0; i < cs.length; i++) {
            final int idx = i;
            addRenderableWidget(Button.builder(Component.literal(cls == i ? "> " : "").append(Component.translatable("class.ironorigins." + cs[i].id)),
                    b -> { cls = idx; rebuildWidgets(); }).bounds(cx + 10, top + i * step, 200, 18).build());
        }
        addRenderableWidget(Button.builder(Component.translatable("screen.ironorigins.confirm"),
                b -> Net.CH.sendToServer(new Net.Choose(race, cls))).bounds(cx - 60, height - 26, 120, 20).build());
    }

    @Override public void render(GuiGraphics g, int mx, int my, float pt) {
        renderBackground(g);
        g.drawCenteredString(font, title, width / 2, 8, 0xFFFFFF);
        g.drawCenteredString(font, Component.translatable("race.ironorigins." + Race.values()[race].id + ".desc"), width / 2, 22, 0xFFD27F);
        g.drawCenteredString(font, Component.translatable("class.ironorigins." + PlayerClass.values()[cls].id + ".desc"), width / 2, 34, 0x9FE3FF);
        super.render(g, mx, my, pt);
    }

    @Override public boolean shouldCloseOnEsc() { return false; }
    @Override public boolean isPauseScreen() { return false; }
}
