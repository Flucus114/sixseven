package dev.ironorigins.client;

import dev.ironorigins.data.PlayerClass;
import dev.ironorigins.data.PlayerData;
import dev.ironorigins.data.SkillTree;
import dev.ironorigins.net.Net;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.Tooltip;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

/** Árvore da classe atual: 3 colunas (ramos) x 3 linhas (níveis). Cada classe tem a sua própria árvore. */
public class TreeScreen extends Screen {
    private static final int COL_W = 134, GAP = 8, ROW_H = 28, TOP = 66;

    public TreeScreen() { super(Component.translatable("screen.ironorigins.tree")); }

    public void rebuild() { rebuildWidgets(); }

    private PlayerClass cls() { return PlayerClass.values()[ClientData.cls]; }

    private int colX(int branch) { return width / 2 - (3 * COL_W + 2 * GAP) / 2 + branch * (COL_W + GAP); }

    private static Component nodeName(SkillTree.Node n) {
        return n.spell() != null
                ? Component.translatable("skill.ironorigins.spell", Component.translatable("spell." + n.spell().replace(':', '.')))
                : Component.literal(n.name());
    }

    @Override protected void init() {
        for (SkillTree.Node n : SkillTree.nodes(cls())) {
            boolean done = ClientData.unlocked.contains(n.id());
            boolean parentOk = n.parent() == null || ClientData.unlocked.contains(n.parent());
            Component label = Component.literal(done ? "[x] " : "").append(nodeName(n)).append(done ? "" : "  (" + n.cost() + ")");
            Button b = Button.builder(label, x -> Net.CH.sendToServer(new Net.Unlock(n.id())))
                    .bounds(colX(n.branch()), TOP + n.tier() * ROW_H, COL_W, 20).build();
            b.active = !done && parentOk && ClientData.points >= n.cost();
            b.setTooltip(Tooltip.create(Component.literal(n.desc() + (done ? "" : "  — custo: " + n.cost() + " pts"))));
            addRenderableWidget(b);
        }
    }

    @Override public void render(GuiGraphics g, int mx, int my, float pt) {
        renderBackground(g);
        super.render(g, mx, my, pt);
        PlayerClass c = cls();
        g.drawCenteredString(font, Component.translatable("class.ironorigins." + c.id).append(" — ").append(title), width / 2, 10, 0xFFFFFF);
        g.drawCenteredString(font, Component.translatable("screen.ironorigins.points", ClientData.points), width / 2, 24, 0xFFD27F);
        String[] names = SkillTree.branchNames(c);
        for (int i = 0; i < names.length; i++) g.drawCenteredString(font, names[i], colX(i) + COL_W / 2, 48, 0x9FE3FF);
        if (c == PlayerClass.COOK)
            g.drawCenteredString(font, Component.translatable("screen.ironorigins.job.cook", PlayerData.level(ClientData.cook), ClientData.cook), width / 2, height - 20, 0xAAAAAA);
        else if (c == PlayerClass.GOLEM_CRAFTER)
            g.drawCenteredString(font, Component.translatable("screen.ironorigins.job.golem", PlayerData.level(ClientData.golem), ClientData.golem), width / 2, height - 20, 0xAAAAAA);
    }
}
