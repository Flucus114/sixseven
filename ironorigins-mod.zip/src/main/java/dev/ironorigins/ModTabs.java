package dev.ironorigins;

import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.RegistryObject;

/** Aba do criativo com todos os itens do mod. */
public final class ModTabs {
    private ModTabs() {}

    public static final DeferredRegister<CreativeModeTab> TABS = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, IronOrigins.MODID);

    public static final RegistryObject<CreativeModeTab> MAIN = TABS.register("main", () -> CreativeModeTab.builder()
            .title(Component.translatable("itemGroup.ironorigins"))
            .icon(() -> new ItemStack(ModItems.WAND.get()))
            .displayItems((params, out) -> ModItems.ITEMS.getEntries().forEach(o -> out.accept(o.get())))
            .build());
}
