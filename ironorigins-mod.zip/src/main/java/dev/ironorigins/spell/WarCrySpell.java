package dev.ironorigins.spell;

import dev.ironorigins.IronOrigins;
import io.redspace.ironsspellbooks.api.config.DefaultConfig;
import io.redspace.ironsspellbooks.api.magic.MagicData;
import io.redspace.ironsspellbooks.api.registry.SchoolRegistry;
import io.redspace.ironsspellbooks.api.spells.*;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;

/** Guerreiro/Clérigo: grito de guerra — força para você e aliados num raio de 8 blocos. */
@AutoSpellConfig
public class WarCrySpell extends AbstractSpell {
    private final ResourceLocation id = new ResourceLocation(IronOrigins.MODID, "war_cry");
    private final DefaultConfig cfg = new DefaultConfig().setMinRarity(SpellRarity.UNCOMMON)
            .setSchoolResource(SchoolRegistry.HOLY_RESOURCE).setMaxLevel(5).setCooldownSeconds(40).build();

    public WarCrySpell() { this.manaCostPerLevel = 10; this.baseSpellPower = 1; this.spellPowerPerLevel = 1; this.castTime = 0; this.baseManaCost = 40; }

    @Override public ResourceLocation getSpellResource() { return id; }
    @Override public DefaultConfig getDefaultConfig() { return cfg; }
    @Override public CastType getCastType() { return CastType.INSTANT; }

    @Override public void onCast(Level level, int spellLevel, LivingEntity entity, CastSource src, MagicData data) {
        for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, entity.getBoundingBox().inflate(8))) {
            if (e == entity || e instanceof Player)
                e.addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST, 200 + spellLevel * 40, Math.min(spellLevel / 2, 2)));
        }
        super.onCast(level, spellLevel, entity, src, data);
    }
}
