package dev.ironorigins.spell;

import dev.ironorigins.IronOrigins;
import io.redspace.ironsspellbooks.api.registry.SpellRegistry;
import io.redspace.ironsspellbooks.api.spells.AbstractSpell;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.RegistryObject;

public final class ModSpells {
    public static final DeferredRegister<AbstractSpell> SPELLS = DeferredRegister.create(SpellRegistry.SPELL_REGISTRY_KEY, IronOrigins.MODID);
    public static final RegistryObject<AbstractSpell> BARK_SKIN = SPELLS.register("bark_skin", BarkSkinSpell::new);
    public static final RegistryObject<AbstractSpell> WAR_CRY = SPELLS.register("war_cry", WarCrySpell::new);
}
