package dev.ironorigins.spell;

import dev.ironorigins.IronOrigins;
import io.redspace.ironsspellbooks.api.config.DefaultConfig;
import io.redspace.ironsspellbooks.api.magic.MagicData;
import io.redspace.ironsspellbooks.api.registry.SchoolRegistry;
import io.redspace.ironsspellbooks.api.spells.*;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.Level;

/** Druida: pele de casca (resistência + regeneração leve). */
@AutoSpellConfig
public class BarkSkinSpell extends AbstractSpell {
    private final ResourceLocation id = new ResourceLocation(IronOrigins.MODID, "bark_skin");
    private final DefaultConfig cfg = new DefaultConfig().setMinRarity(SpellRarity.COMMON)
            .setSchoolResource(SchoolRegistry.NATURE_RESOURCE).setMaxLevel(5).setCooldownSeconds(25).build();

    public BarkSkinSpell() { this.manaCostPerLevel = 8; this.baseSpellPower = 1; this.spellPowerPerLevel = 1; this.castTime = 0; this.baseManaCost = 25; }

    @Override public ResourceLocation getSpellResource() { return id; }
    @Override public DefaultConfig getDefaultConfig() { return cfg; }
    @Override public CastType getCastType() { return CastType.INSTANT; }

    @Override public void onCast(Level level, int spellLevel, LivingEntity entity, CastSource src, MagicData data) {
        entity.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 200 + spellLevel * 60, Math.min(spellLevel / 2, 2)));
        entity.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 100 + spellLevel * 20, 0));
        super.onCast(level, spellLevel, entity, src, data);
    }
}
