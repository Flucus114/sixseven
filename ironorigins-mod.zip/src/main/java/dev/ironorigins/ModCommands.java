package dev.ironorigins;

import com.mojang.brigadier.context.CommandContext;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** /ironorigins reset [jogador] — apaga raça/classe/árvore e reabre a tela de escolha (op nível 2). Útil para testar classes. */
@Mod.EventBusSubscriber(modid = IronOrigins.MODID)
public final class ModCommands {
    private ModCommands() {}

    @SubscribeEvent public static void register(RegisterCommandsEvent e) {
        e.getDispatcher().register(Commands.literal("ironorigins").requires(s -> s.hasPermission(2))
                .then(Commands.literal("reset")
                        .executes(c -> reset(c, c.getSource().getPlayerOrException()))
                        .then(Commands.argument("player", EntityArgument.player())
                                .executes(c -> reset(c, EntityArgument.getPlayer(c, "player"))))));
    }

    private static int reset(CommandContext<CommandSourceStack> c, ServerPlayer p) {
        Logic.reset(p);
        c.getSource().sendSuccess(() -> Component.translatable("msg.ironorigins.reset", p.getDisplayName()), true);
        return 1;
    }
}
