package dev.ironorigins;

import dev.ironorigins.data.PlayerClass;
import dev.ironorigins.data.PlayerData;
import dev.ironorigins.data.SkillTree;
import dev.ironorigins.items.AnglerRod;
import dev.ironorigins.items.ClassBow;
import dev.ironorigins.items.ClassGear;
import dev.ironorigins.items.FishStew;
import dev.ironorigins.net.Net;
import io.redspace.ironsspellbooks.api.registry.SpellRegistry;
import io.redspace.ironsspellbooks.api.spells.AbstractSpell;
import java.util.List;
import java.util.Set;
import net.minecraft.core.NonNullList;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.ItemTags;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.projectile.AbstractArrow;
import net.minecraft.world.item.Items;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.boss.enderdragon.EnderDragon;
import net.minecraft.world.entity.boss.wither.WitherBoss;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.common.Tags;
import net.minecraftforge.event.entity.EntityJoinLevelEvent;
import net.minecraftforge.event.entity.ProjectileImpactEvent;
import net.minecraftforge.event.entity.living.LivingDropsEvent;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.minecraftforge.event.entity.player.ItemTooltipEvent;
import net.minecraftforge.event.entity.living.LivingEntityUseItemEvent;
import net.minecraftforge.event.entity.player.ItemFishedEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.event.entity.player.PlayerXpEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.network.PacketDistributor;
import net.minecraftforge.registries.ForgeRegistries;

public class CommonEvents {
    private static final Set<String> IRON_BOSSES = Set.of("dead_king", "keeper", "citadel_keeper", "fire_boss"); // confira os IDs reais no Iron's

    @SubscribeEvent public void login(PlayerEvent.PlayerLoggedInEvent e) { init(e.getEntity()); }
    @SubscribeEvent public void respawn(PlayerEvent.PlayerRespawnEvent e) { init(e.getEntity()); }

    private void init(Player pl) {
        if (!(pl instanceof ServerPlayer p)) return;
        if (PlayerData.race(p) == null) Net.CH.send(PacketDistributor.PLAYER.with(() -> p), new Net.OpenSelect());
        else { Logic.refresh(p); Logic.sync(p); }
    }

    @SubscribeEvent public void clone(PlayerEvent.Clone e) {
        if (!e.isWasDeath()) return;
        CompoundTag old = e.getOriginal().getPersistentData();
        if (old.contains(Player.PERSISTED_NBT_TAG))
            e.getEntity().getPersistentData().put(Player.PERSISTED_NBT_TAG, old.getCompound(Player.PERSISTED_NBT_TAG).copy());
    }

    /** +1 ponto de habilidade por nível de XP ganho. */
    @SubscribeEvent public void levelUp(PlayerXpEvent.LevelChange e) {
        if (e.getLevels() > 0 && e.getEntity() instanceof ServerPlayer p && PlayerData.cls(p) != null) {
            PlayerData.addPoints(p, e.getLevels());
            Logic.sync(p);
        }
    }

    /** Bosses: +3 pontos e um pergaminho aleatório (único jeito, com a árvore, de conseguir feitiços). */
    @SubscribeEvent public void bossDrops(LivingDropsEvent e) {
        LivingEntity v = e.getEntity();
        var key = ForgeRegistries.ENTITY_TYPES.getKey(v.getType());
        boolean boss = v instanceof EnderDragon || v instanceof WitherBoss || v.getType().is(Tags.EntityTypes.BOSSES)
                || (key != null && key.getNamespace().equals("irons_spellbooks") && IRON_BOSSES.contains(key.getPath()));
        Entity src = e.getSource().getEntity();
        if (!boss || !(src instanceof ServerPlayer sp)) return;
        PlayerData.addPoints(sp, 3);
        Logic.sync(sp);
        List<AbstractSpell> all = SpellRegistry.getEnabledSpells();
        if (all.isEmpty()) return;
        AbstractSpell s = all.get(v.getRandom().nextInt(all.size()));
        int lvl = Math.min(s.getMaxLevel(), 2 + v.getRandom().nextInt(3));
        ItemStack st = Logic.scroll(s.getSpellId(), lvl);
        if (!st.isEmpty()) e.getDrops().add(new ItemEntity(v.level(), v.getX(), v.getY(), v.getZ(), st));
        sp.sendSystemMessage(Component.translatable("msg.ironorigins.boss"));
    }

    private static boolean holdsRod(Player p) {
        return p.getMainHandItem().getItem() instanceof AnglerRod || p.getOffhandItem().getItem() instanceof AnglerRod;
    }

    /** Peixes raros por bioma. O Cozinheiro tem chance bem maior (e crescente com o nível); outras classes, só uma chance baixa. */
    @SubscribeEvent public void fished(ItemFishedEvent e) {
        Player pl = e.getHookEntity().getPlayerOwner();
        if (!(pl instanceof ServerPlayer sp)) return;
        String biome = pl.level().getBiome(e.getHookEntity().blockPosition()).unwrapKey().map(k -> k.location().getPath()).orElse("");
        Fish f = Fish.forBiome(biome);
        if (f == null) return;
        boolean cook = PlayerData.cls(sp) == PlayerClass.COOK;
        int lvl = cook ? PlayerData.level(sp, "cook") : 0;
        float chance = cook ? 0.35F + 0.03F * lvl + (float) SkillTree.perk(sp, "rare_fish") : 0.12F;
        if (holdsRod(sp)) chance += 0.10F;
        NonNullList<ItemStack> d = e.getDrops();
        if (!d.isEmpty() && d.get(0).is(ItemTags.FISHES) && sp.getRandom().nextFloat() < chance) {
            d.set(0, new ItemStack(ModItems.RAW.get(f).get()));
            if (cook) { PlayerData.addXp(sp, "cook", 6); Logic.sync(sp); }
        }
    }

    /** Comer peixe cozido/ensopado dá buff. O nível de Cozinheiro e os perks da árvore só valem para a classe Cozinheiro. */
    @SubscribeEvent public void eaten(LivingEntityUseItemEvent.Finish e) {
        if (!(e.getEntity() instanceof ServerPlayer sp)) return;
        boolean cook = PlayerData.cls(sp) == PlayerClass.COOK;
        int lvl = cook ? PlayerData.level(sp, "cook") : 0;
        double mult = 1.0 + (cook ? SkillTree.perk(sp, "buff_duration") : 0);
        for (Fish f : Fish.values()) {
            if (e.getItem().is(ModItems.COOKED.get(f).get())) {
                sp.addEffect(new MobEffectInstance(f.effect, (int) ((600 + 200 * lvl) * mult), Math.min(lvl / 4, 2)));
                if (cook) { PlayerData.addXp(sp, "cook", 3); Logic.sync(sp); }
            }
        }
        if (e.getItem().getItem() instanceof FishStew) {
            sp.addEffect(new MobEffectInstance(MobEffects.REGENERATION, (int) ((200 + 100 * lvl) * mult), 0));
            sp.addEffect(new MobEffectInstance(MobEffects.SATURATION, 40 + 10 * lvl, 0));
            if (cook) { PlayerData.addXp(sp, "cook", 4); Logic.sync(sp); }
        }
    }

    /** Flechas: bônus do arco de classe, perks do Arqueiro (dano / recuperar flecha). Roda uma única vez por flecha. */
    @SubscribeEvent public void arrowJoin(EntityJoinLevelEvent e) {
        if (e.getLevel().isClientSide || !(e.getEntity() instanceof AbstractArrow a)) return;
        if (a.getPersistentData().getBoolean("io_boosted") || !(a.getOwner() instanceof LivingEntity owner)) return;
        a.getPersistentData().putBoolean("io_boosted", true);
        double mult = 1.0;
        ItemStack held = owner.getUseItem().getItem() instanceof ClassBow ? owner.getUseItem() : owner.getMainHandItem();
        if (held.getItem() instanceof ClassBow bow) {
            a.setBaseDamage(a.getBaseDamage() + bow.bonusDamage());
            if (bow.special() == ClassBow.Special.FIRE) a.setSecondsOnFire(100);
            if (bow.special() == ClassBow.Special.FROST) a.getPersistentData().putBoolean("io_frost", true);
            if (owner instanceof ServerPlayer sp && PlayerData.cls(sp) == PlayerClass.ARCHER) mult += 0.15;
        }
        if (owner instanceof ServerPlayer sp) {
            mult += SkillTree.perk(sp, "arrow_damage");
            double save = SkillTree.perk(sp, "arrow_save");
            if (save > 0 && a.pickup == AbstractArrow.Pickup.ALLOWED && sp.getRandom().nextDouble() < save) Logic.give(sp, new ItemStack(Items.ARROW));
        }
        a.setBaseDamage(a.getBaseDamage() * mult);
    }

    /** Flecha glacial: lentidão ao acertar. */
    @SubscribeEvent public void arrowHit(ProjectileImpactEvent e) {
        if (!(e.getProjectile() instanceof AbstractArrow a) || a.level().isClientSide) return;
        if (e.getRayTraceResult() instanceof EntityHitResult hit && hit.getEntity() instanceof LivingEntity t && a.getPersistentData().getBoolean("io_frost"))
            t.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 100, 1));
    }

    /** Afinidade: +15% de dano corpo a corpo com arma da SUA classe. */
    @SubscribeEvent public void hurt(LivingHurtEvent e) {
        if (e.getSource().getEntity() instanceof ServerPlayer sp && e.getSource().getDirectEntity() == sp
                && sp.getMainHandItem().getItem() instanceof ClassGear g && !(sp.getMainHandItem().getItem() instanceof ClassBow)
                && g.gearClass() == PlayerData.cls(sp))
            e.setAmount(e.getAmount() * 1.15F);
    }

    /** Tooltip: classe do item + descrição (chave <item>.desc). */
    @SubscribeEvent public void tooltip(ItemTooltipEvent e) {
        if (e.getItemStack().getItem() instanceof ClassGear g) {
            e.getToolTip().add(Component.translatable("tooltip.ironorigins.class", Component.translatable("class.ironorigins." + g.gearClass().id)).withStyle(ChatFormatting.GOLD));
            e.getToolTip().add(Component.translatable(e.getItemStack().getItem().getDescriptionId() + ".desc").withStyle(ChatFormatting.GRAY));
        }
    }
}
